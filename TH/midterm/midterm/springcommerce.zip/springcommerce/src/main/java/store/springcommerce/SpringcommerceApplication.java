package store.springcommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcommerceApplication.class, args);
	}

}
