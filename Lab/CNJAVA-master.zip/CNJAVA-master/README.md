# About this repository
- Repo này sử dụng để lưu trữ và nộp các bài lab(thực hành và lý thuyết) của môn `Công nghệ java` tại trường đại học TDTU.

# Structure
- Repo bao gồm các bài lab của thực hành và lý thuyết
## Thực hành
- Các bài lab thực hành được lưu trữ tại  [tại đây](./TH/)
- branch `master` lưu trữ các bài lab đã hoàn thành

## Thực hành
- Các bài lab lý thuyết được lưu trữ tại  [tại đây](./LT/)
- branch `master` lưu trữ các bài lab đã hoàn thành
# Issues
- Nếu có bất kỳ vấn đề gì thầy/cô có thể đặt câu hỏi cho em [tại đây](https://github.com/trongtinh7727/CNJAVA/issues)
 # Em xin cảm ơn