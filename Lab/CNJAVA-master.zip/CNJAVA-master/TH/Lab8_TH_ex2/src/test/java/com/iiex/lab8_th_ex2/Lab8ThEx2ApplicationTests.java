package com.iiex.lab8_th_ex2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab8ThEx2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
