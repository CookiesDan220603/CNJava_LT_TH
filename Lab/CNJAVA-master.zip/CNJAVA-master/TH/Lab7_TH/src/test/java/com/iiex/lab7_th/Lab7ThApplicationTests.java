package com.iiex.lab7_th;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab7ThApplicationTests {

    @Test
    void contextLoads() {
    }

}
