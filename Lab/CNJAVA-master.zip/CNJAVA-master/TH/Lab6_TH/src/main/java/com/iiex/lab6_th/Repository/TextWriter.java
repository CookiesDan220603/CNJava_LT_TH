package com.iiex.lab6_th.Repository;

public interface TextWriter {
    void write(String fileName, String text);
}
