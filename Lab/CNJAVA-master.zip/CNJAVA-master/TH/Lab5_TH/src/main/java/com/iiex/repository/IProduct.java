package com.iiex.repository;

import com.iiex.model.Product;

public interface IProduct extends genericDAO<Product> {

}
