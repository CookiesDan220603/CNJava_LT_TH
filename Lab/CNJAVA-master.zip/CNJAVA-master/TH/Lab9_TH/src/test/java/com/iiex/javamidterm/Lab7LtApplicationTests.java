package com.iiex.javamidterm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab7LtApplicationTests {

    @Test
    void contextLoads() {
    }

}
