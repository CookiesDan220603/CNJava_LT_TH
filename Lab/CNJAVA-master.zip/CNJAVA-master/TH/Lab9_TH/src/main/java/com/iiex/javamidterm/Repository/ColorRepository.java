package com.iiex.javamidterm.Repository;

import com.iiex.javamidterm.Model.Color;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ColorRepository extends JpaRepository<Color, Integer> {
}
