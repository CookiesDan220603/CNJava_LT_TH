package com.iiex.javamidterm.DTO;

public class ProductDTO {

}
