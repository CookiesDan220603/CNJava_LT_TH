package com.iiex.lab7_th_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab7Th2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
