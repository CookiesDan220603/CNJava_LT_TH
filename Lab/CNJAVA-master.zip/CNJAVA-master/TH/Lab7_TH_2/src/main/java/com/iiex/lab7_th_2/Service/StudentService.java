package com.iiex.lab7_th_2.Service;

public interface StudentService {

}
