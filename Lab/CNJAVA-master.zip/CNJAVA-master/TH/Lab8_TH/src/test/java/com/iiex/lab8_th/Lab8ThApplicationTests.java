package com.iiex.lab8_th;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab8ThApplicationTests {

    @Test
    void contextLoads() {
    }

}
