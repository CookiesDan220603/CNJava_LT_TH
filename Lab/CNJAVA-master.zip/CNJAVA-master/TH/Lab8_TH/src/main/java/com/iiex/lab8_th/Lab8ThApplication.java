package com.iiex.lab8_th;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab8ThApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab8ThApplication.class, args);
    }

}
