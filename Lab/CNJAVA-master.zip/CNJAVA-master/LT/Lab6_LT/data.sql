CREATE TABLE student(
                        ID INT PRIMARY KEY AUTO_INCREMENT,
                        name VARCHAR(50),
                        course Varchar(50),
                        fee int
);