package com.iiex.lab7_lt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab7LtApplicationTests {

    @Test
    void contextLoads() {
    }

}
