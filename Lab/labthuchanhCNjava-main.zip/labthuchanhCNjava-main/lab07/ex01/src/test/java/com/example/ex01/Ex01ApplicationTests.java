package com.example.ex01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
