package tdtu.edu.ex02.services;

import org.springframework.stereotype.Service;
import tdtu.edu.ex02.models.Student;
import tdtu.edu.ex02.repository.StudentRepository;

@Service
public interface StudentService extends StudentRepository {

}
