package tdtu.edu.ex03.services;

import org.springframework.stereotype.Service;
import tdtu.edu.ex03.repository.StudentRepository;

@Service
public interface StudentService extends StudentRepository {

}
