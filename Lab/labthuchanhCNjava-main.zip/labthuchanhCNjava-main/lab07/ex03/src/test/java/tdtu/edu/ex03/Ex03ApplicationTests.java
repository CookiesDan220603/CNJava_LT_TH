package tdtu.edu.ex03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
