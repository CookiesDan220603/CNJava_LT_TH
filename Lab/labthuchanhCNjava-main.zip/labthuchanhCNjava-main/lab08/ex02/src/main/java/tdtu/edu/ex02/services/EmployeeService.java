package tdtu.edu.ex02.services;

import tdtu.edu.ex02.repository.EmployeeRepository;

public interface EmployeeService extends EmployeeRepository {
}
