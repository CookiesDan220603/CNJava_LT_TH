package tdtu.edu.springecommerce.services.intservices;

import org.springframework.stereotype.Service;
import tdtu.edu.springecommerce.repostiory.BrandRepository;

@Service
public interface BrandService extends BrandRepository {
}
