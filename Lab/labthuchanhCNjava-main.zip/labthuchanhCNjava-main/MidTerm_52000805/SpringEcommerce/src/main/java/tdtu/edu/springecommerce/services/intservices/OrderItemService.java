package tdtu.edu.springecommerce.services.intservices;

import org.springframework.stereotype.Service;
import tdtu.edu.springecommerce.repostiory.OrderItemRepository;

@Service
public interface OrderItemService extends OrderItemRepository {
}
