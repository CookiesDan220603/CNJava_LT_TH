package tdtu.edu.springecommerce.services.intservices;

import org.springframework.stereotype.Service;
import tdtu.edu.springecommerce.repostiory.CategoryRepository;

@Service
public interface CategoryService extends CategoryRepository {
}
