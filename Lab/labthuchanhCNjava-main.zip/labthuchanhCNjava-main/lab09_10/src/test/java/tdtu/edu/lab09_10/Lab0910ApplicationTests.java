package tdtu.edu.lab09_10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab0910ApplicationTests {

	@Test
	void contextLoads() {
	}

}
