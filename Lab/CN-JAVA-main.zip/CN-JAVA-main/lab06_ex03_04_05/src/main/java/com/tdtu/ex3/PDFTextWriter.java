package com.tdtu.ex3;

public class PDFTextWriter {
	public void write(String fileName, String text) {

    }
}
