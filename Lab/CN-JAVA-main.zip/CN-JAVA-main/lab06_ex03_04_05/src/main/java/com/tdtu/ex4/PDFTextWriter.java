package com.tdtu.ex4;

import org.springframework.stereotype.Component;

@Component
public class PDFTextWriter implements TextWriter{
    @Override
    public void write(String fileName, String text) {

    }
}
