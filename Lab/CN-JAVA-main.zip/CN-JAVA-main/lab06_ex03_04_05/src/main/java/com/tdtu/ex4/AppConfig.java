package com.tdtu.ex4;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.tdtu.lab06_ex004")
public class AppConfig {

}
