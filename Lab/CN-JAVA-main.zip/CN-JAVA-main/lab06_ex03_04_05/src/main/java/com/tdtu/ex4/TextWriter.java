package com.tdtu.ex4;

public interface TextWriter {
	void write(String fileName, String text);
}
