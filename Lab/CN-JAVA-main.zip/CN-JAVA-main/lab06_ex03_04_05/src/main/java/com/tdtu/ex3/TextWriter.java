package com.tdtu.ex3;

public interface TextWriter {
	void write(String fileName, String text);
}
