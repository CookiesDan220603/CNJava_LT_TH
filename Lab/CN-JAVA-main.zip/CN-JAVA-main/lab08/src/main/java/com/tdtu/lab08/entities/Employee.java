package com.tdtu.lab08.entities;

public class Employee {

}
