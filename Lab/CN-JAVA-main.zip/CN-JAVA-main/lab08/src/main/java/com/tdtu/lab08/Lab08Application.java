package com.tdtu.lab08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab08Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab08Application.class, args);
	}

}
